package ExtraClase;

public class Persona {
	
	int pin;
	int monto;
	int saldo;
	
	public void setPin(int pin) {
		this.pin=pin;
	}
	public void setSaldo(int saldo) {
		this.saldo=saldo;
	}
	public void setMonto(int monto) {
		this.monto=monto;
	}
	public int getMonto() {
		return this.monto;
	}
	public int getPin() {
		return this.pin;
	}
	public int getSaldo() {
		return this.saldo;
	}
	
}
